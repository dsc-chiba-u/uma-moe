// include/strata/core/mem_info.hpp - the current device's free memory, including what a unified-memory GPU can take.
//
// On an integrated GPU (DGX Spark / GB10: one 128 GB pool for the CPU and the GPU) `cudaMemGetInfo` reports the
// kernel's MemFree, which leaves out the page cache - after the model's GGUFs have been read that is ~70 GB the
// kernel hands back to the first allocation that asks.  Sizing the expert cache by it keeps ~95% of the experts off
// the GPU.  So there the free figure is MemAvailable (free + reclaimable), what cudaMalloc can actually get.
#pragma once

#include <cuda_runtime.h>

#include <cstddef>
#include <cstdio>

namespace strata::core {

inline cudaError_t mem_get_info(size_t* free_b, size_t* total_b) {
    const cudaError_t e = cudaMemGetInfo(free_b, total_b);
#if defined(__linux__)
    if (e != cudaSuccess) return e;
    int dev = 0, integrated = 0;
    if (cudaGetDevice(&dev) != cudaSuccess || cudaDeviceGetAttribute(&integrated, cudaDevAttrIntegrated, dev) != cudaSuccess) {
        cudaGetLastError();
        return e;
    }
    if (!integrated) return e;
    if (FILE* f = std::fopen("/proc/meminfo", "r")) {
        char line[128];
        unsigned long long kb = 0;
        while (std::fgets(line, sizeof line, f))
            if (std::sscanf(line, "MemAvailable: %llu kB", &kb) == 1) break;
        std::fclose(f);
        if ((size_t) kb * 1024 > *free_b) *free_b = (size_t) kb * 1024;
    }
#endif
    return e;
}

/// Whether the current device shares the host's memory (DGX Spark / GB10).  There a "PCIe" read of a pinned host
/// blob is the GPU reading the same DRAM as its own allocations: the miss path wants no CPU share and no staging.
inline bool device_integrated() {
    int dev = 0, integrated = 0;
    if (cudaGetDevice(&dev) != cudaSuccess || cudaDeviceGetAttribute(&integrated, cudaDevAttrIntegrated, dev) != cudaSuccess) {
        cudaGetLastError();
        return false;
    }
    return integrated != 0;
}

}  // namespace strata::core
