// include/strata/core/tiered_source.hpp - experts that do not fit in RAM: a pinned DRAM cache over the SSD.
//
// On a unified-memory GPU (DGX Spark / GB10) the GPU reads a pinned host blob in place as fast as its own copy of
// it, so the expert cache that matters is the one in pinned host memory, and there is exactly one copy of every
// cached expert: the GPU computes it straight out of the slot it was read into.  This source holds `slots` such
// slots over the pack's `experts.bin` (one 4 KiB-aligned blob per (layer, expert), the GGUF slices as they are)
// and serves the rest from the SSD with unbuffered reads:
//
//   * `begin_layer` (the verify window's pool, once per layer, as soon as the routing is known) admits the layer's
//     missing experts: least recently used slots are evicted and the reads are queued, many in flight at once.
//     The window's plan then sends the resident experts to the GPU at once and the arriving ones after
//     `wait_loads`, so the GPU computes the hits while the SSD delivers the misses.
//   * `blob` of an expert that is not resident reads it into a bounce buffer WITHOUT admitting it (the VRAM tier's
//     fill and other one-off readers), valid until the next `blob` call - the ExpertSource contract.
//
// Experts the VRAM tier holds (`set_vram_residency`) are never admitted: one copy per expert across both tiers.
//
// EVICTION IS SAFE BECAUSE THE WINDOW IS LAYER-ORDERED.  The host serves layer L when the GPU rings layer L, which
// it does after every expert of layers < L was computed (one stream), so only layer L's own slots can still be read
// by the GPU; those were touched first and sit at the most-recently-used end, and a slot touched in the current
// layer is skipped by the eviction scan regardless.
#pragma once

#include "strata/core/expert_source.hpp"
#include "strata/platform/direct_file.hpp"

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace strata::core {

class TieredExpertSource : public ExpertSource {
public:
    struct Stats {
        int64_t lookups = 0;       ///< distinct (layer, expert) pairs asked for by begin_layer, VRAM ones excluded
        int64_t hits = 0;          ///< ... already resident (or in flight from an earlier layer's admission)
        int64_t loads = 0;         ///< ... admitted: read from the SSD
        int64_t bounce = 0;        ///< blob() reads that were not admitted
        uint64_t bytes = 0;        ///< bytes read from the SSD (admissions + bounce + warm fill)
        double wait_ms = 0;        ///< time wait_loads blocked
        int64_t waited_layers = 0; ///< layers whose wait_loads found reads still in flight
        int64_t prefetched = 0;    ///< experts admitted by prefetch (pre-gating)
        int64_t prefetch_used = 0; ///< ... later asked for by begin_layer (a correct prediction)
        int64_t prefetch_evicted = 0;   ///< ... evicted before anything asked for them
        int64_t late = 0;          ///< begin_layer found the expert still loading (prefetched or admitted earlier)
    };

    TieredExpertSource() = default;
    ~TieredExpertSource() override;
    TieredExpertSource(const TieredExpertSource&) = delete;
    TieredExpertSource& operator=(const TieredExpertSource&) = delete;

    /// `experts_bin`: the pack's experts.bin (layout from `expert_layout()`); `slots` blobs of pinned DRAM.
    bool open(const std::string& experts_bin, int64_t n_layers, int64_t n_expert, int64_t slots, std::string& err);
    void close();

    /// The VRAM tier's host residency table ([layer * n_expert + expert] >= 0: in VRAM); those are never admitted.
    void set_vram_residency(const int32_t* host_res) { vram_res_ = host_res; }
    /// Warm start: admit the pairs in `order` (a routing-frequency profile) into free slots until none is left.
    bool warm_fill(const std::vector<std::pair<int32_t, int32_t>>& order, std::string& err);

    const uint8_t* blob(int64_t layer, int64_t expert) override;
    int64_t reads() const override { return stats_.loads + stats_.bounce; }
    bool pinned(int64_t layer, int64_t expert) const override;
    const uint8_t* device_alias(int64_t layer, int64_t expert) const override;
    void begin_layer(int64_t layer, const int32_t* ids, int64_t k) override;
    void prefetch(int64_t layer, const int32_t* ids, int64_t n) override;
    bool tiered() const override { return true; }
    bool loading(int64_t layer, int64_t expert) const override;
    bool wait_loads(std::string& err) override;

    /// The prompt path's bypass: (layer, expert)'s blob read into `dst` (page-aligned, slot_bytes() long) without
    /// admitting it; `delta` = the blob's offset in `dst`.  Thread-safe (its own descriptor, plain preads).
    bool read_blob_sync(int64_t layer, int64_t expert, uint8_t* dst, uint32_t& delta, std::string& err) const override;

    int64_t slots() const { return n_slots_; }
    uint64_t slot_bytes() const { return slot_bytes_; }
    int64_t resident() const;
    const Stats& stats() const { return stats_; }
    const std::string& note() const { return note_; }

private:
    enum : uint8_t { kFree = 0, kReady = 1, kLoading = 2 };
    int64_t key(int64_t layer, int64_t expert) const { return layer * n_expert_ + expert; }
    void unlink(int32_t s);
    void push_front(int32_t s);
    int32_t victim();
    bool issue(int32_t s, int64_t layer, int64_t expert, std::string& err);   // slot s <- (layer, expert) from the SSD
    bool submit_range(int32_t owner, uint8_t* dst, uint64_t at, uint64_t total, int32_t& n_chunks, std::string& err);
    bool reap(bool block, std::string& err);                                  // completions -> slot states

    struct Chunk { int32_t owner = -1; uint64_t at = 0; uint32_t len = 0; };   ///< one queued read (tag = index)
    std::vector<Chunk> chunks_;
    std::vector<uint32_t> free_chunks_;
    std::string fail_;                      ///< the first read failure, reported by wait_loads

    strata::platform::DirectFile file_;
    int sync_fd_ = -1;                      ///< read_blob_sync's own O_DIRECT descriptor
    void* arena_ = nullptr;                 ///< PinnedArena, owned
    uint8_t* host_ = nullptr;               ///< slot 0, host
    const uint8_t* dev_ = nullptr;          ///< slot 0, device alias
    uint8_t* bounce_ = nullptr;             ///< blob() of a non-resident expert
    int64_t bounce_left_ = 0;               ///< bounce chunks still in flight
    int64_t n_layers_ = 0, n_expert_ = 0, n_slots_ = 0;
    uint64_t slot_bytes_ = 0;
    std::vector<int32_t> slot_of_;          ///< [layer * n_expert + expert] -> slot or -1
    std::vector<int32_t> key_of_;           ///< [slot] -> key or -1
    std::vector<uint32_t> delta_;           ///< [slot] -> the blob's offset inside the slot (unaligned blobs)
    std::vector<uint8_t> state_;
    std::vector<int32_t> left_;             ///< [slot] -> read chunks still in flight
    std::vector<int32_t> prev_, next_;      ///< LRU list: head_ = most recent
    std::vector<uint32_t> stamp_;           ///< [slot] -> the layer serial that last touched it
    std::vector<uint8_t> prefetched_;       ///< [slot] -> admitted by prefetch, not yet asked for
    std::vector<int32_t> need_;             ///< the current layer's slots still loading: what wait_loads waits for
    int32_t head_ = -1, tail_ = -1;
    uint32_t serial_ = 1;                   ///< one per begin_layer
    int64_t in_flight_ = 0;                 ///< slots in kLoading
    const int32_t* vram_res_ = nullptr;
    Stats stats_;
    std::string note_;
};

}  // namespace strata::core
