// include/strata/platform/spin.hpp - the two x86 intrinsics the engine's spin loops and doorbells use, on any CPU.
//
// On x86 this is <immintrin.h> itself.  Elsewhere (aarch64: DGX Spark / GB10) `_mm_pause` becomes the ISA's spin
// hint and `_mm_sfence` a release fence: every caller uses it to order plain stores before a flag store another
// thread or the GPU reads.  aarch64 gets a full-system `dmb sy`, not the inner-shareable fence a C++ fence emits,
// because the reader can be the GPU on the other side of the coherent C2C link.
#pragma once

#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86)
#include <immintrin.h>
#else
#include <atomic>
inline void _mm_pause() noexcept {
#if defined(__aarch64__) || defined(__arm__)
    __asm__ __volatile__("yield" ::: "memory");
#endif
}
inline void _mm_sfence() noexcept {
#if defined(__aarch64__)
    __asm__ __volatile__("dmb sy" ::: "memory");
#else
    std::atomic_thread_fence(std::memory_order_seq_cst);
#endif
}
#endif
