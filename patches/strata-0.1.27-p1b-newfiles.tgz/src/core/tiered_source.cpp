// src/core/tiered_source.cpp - see include/strata/core/tiered_source.hpp.
#include "strata/core/tiered_source.hpp"
#include "strata/core/pinned.hpp"
#include "strata/kernels/cpu/expert_layout.hpp"

#include <cuda_runtime.h>

#include <algorithm>
#include <chrono>
#include <cstdio>

#include <fcntl.h>
#include <unistd.h>

namespace strata::core {

using strata::platform::Completion;
using strata::platform::DirectFile;

namespace {
constexpr uint64_t kChunk = 1ull << 20;   // a 5.2 MB Q8_0 blob is in flight on ~5 reader threads at once
constexpr int32_t kBounce = -2;
}  // namespace

TieredExpertSource::~TieredExpertSource() { close(); }

bool TieredExpertSource::open(const std::string& experts_bin, int64_t n_layers, int64_t n_expert, int64_t slots,
                              std::string& err) {
    close();
    const strata::kernels::cpu::ExpertLayout& lay = strata::kernels::cpu::expert_layout();
    if (lay.n_layers != n_layers || lay.n_expert != n_expert) {
        err = "TieredExpertSource: the expert layout was loaded for a different geometry";
        return false;
    }
    if (slots < 64) {
        err = "TieredExpertSource: at least 64 slots (a verify window's layer routes up to 60 experts)";
        return false;
    }
    if (!file_.open(experts_bin, err)) return false;
    sync_fd_ = ::open(experts_bin.c_str(), O_RDONLY | O_DIRECT);
    if (sync_fd_ < 0) { err = "TieredExpertSource: cannot open " + experts_bin; close(); return false; }
    if (file_.size() < lay.total) {
        char buf[300];
        std::snprintf(buf, sizeof buf, "TieredExpertSource: %s is %llu B but the layout needs %llu B", experts_bin.c_str(),
                      (unsigned long long) file_.size(), (unsigned long long) lay.total);
        err = buf;
        close();
        return false;
    }
    const uint64_t A = DirectFile::alignment();
    // a blob that does not start on a page is read with the page before it: one page of slack per slot
    slot_bytes_ = ((lay.max_blob + A - 1) / A + 1) * A;
    PinnedArena* a = new PinnedArena(slot_bytes_ * (uint64_t) slots);
    if (!a->valid() || a->registered_bytes < slot_bytes_ * (uint64_t) slots) {
        err = "TieredExpertSource: " + std::to_string(slots) + " slots (" +
              std::to_string((slot_bytes_ * (uint64_t) slots) >> 20) + " MiB) could not be pinned: " + a->note;
        delete a;
        close();
        return false;
    }
    void* d = nullptr;
    if (cudaHostGetDevicePointer(&d, a->data(), 0) != cudaSuccess) {
        (void) cudaGetLastError();
        err = "TieredExpertSource: the pinned slots have no device alias";
        delete a;
        close();
        return false;
    }
    arena_ = a;
    host_ = a->data();
    dev_ = (const uint8_t*) d;
    bounce_ = (uint8_t*) DirectFile::alloc_aligned((size_t) slot_bytes_);
    if (bounce_ == nullptr) { err = "TieredExpertSource: cannot allocate the bounce buffer"; close(); return false; }
    n_layers_ = n_layers;
    n_expert_ = n_expert;
    n_slots_ = slots;
    slot_of_.assign((size_t) (n_layers * n_expert), -1);
    key_of_.assign((size_t) slots, -1);
    delta_.assign((size_t) slots, 0);
    state_.assign((size_t) slots, kFree);
    left_.assign((size_t) slots, 0);
    prev_.assign((size_t) slots, -1);
    next_.assign((size_t) slots, -1);
    stamp_.assign((size_t) slots, 0);
    prefetched_.assign((size_t) slots, 0);
    need_.clear();
    head_ = tail_ = -1;
    for (int32_t s = 0; s < (int32_t) slots; ++s) push_front(s);   // slot 0 at the tail: taken first
    serial_ = 1;
    in_flight_ = 0;
    bounce_left_ = 0;
    fail_.clear();
    stats_ = Stats{};
    note_ = std::to_string(slots) + " slots of " + std::to_string(slot_bytes_ >> 10) + " KiB (" +
            std::to_string((slot_bytes_ * (uint64_t) slots) >> 30) + " GiB pinned, " + a->note + ") over " + experts_bin;
    return true;
}

void TieredExpertSource::close() {
    std::string err;
    while ((in_flight_ > 0 || bounce_left_ > 0) && file_.is_open() && reap(true, err)) {}
    file_.close();
    if (sync_fd_ >= 0) ::close(sync_fd_);
    sync_fd_ = -1;
    if (arena_ != nullptr) delete (PinnedArena*) arena_;
    arena_ = nullptr;
    host_ = nullptr;
    dev_ = nullptr;
    if (bounce_ != nullptr) DirectFile::free_aligned(bounce_);
    bounce_ = nullptr;
    n_slots_ = 0;
    in_flight_ = 0;
    bounce_left_ = 0;
    chunks_.clear();
    free_chunks_.clear();
}

void TieredExpertSource::unlink(int32_t s) {
    const int32_t p = prev_[(size_t) s], n = next_[(size_t) s];
    if (p >= 0) next_[(size_t) p] = n; else if (head_ == s) head_ = n;
    if (n >= 0) prev_[(size_t) n] = p; else if (tail_ == s) tail_ = p;
    prev_[(size_t) s] = next_[(size_t) s] = -1;
}

void TieredExpertSource::push_front(int32_t s) {
    prev_[(size_t) s] = -1;
    next_[(size_t) s] = head_;
    if (head_ >= 0) prev_[(size_t) head_] = s;
    head_ = s;
    if (tail_ < 0) tail_ = s;
}

int32_t TieredExpertSource::victim() {
    for (int32_t s = tail_; s >= 0; s = prev_[(size_t) s])
        if (stamp_[(size_t) s] != serial_ && state_[(size_t) s] != kLoading) return s;
    return -1;
}

bool TieredExpertSource::submit_range(int32_t owner, uint8_t* dst, uint64_t at, uint64_t total, int32_t& n_chunks,
                                      std::string& err) {
    n_chunks = 0;
    for (uint64_t o = 0; o < total; o += kChunk) {
        const uint32_t len = (uint32_t) std::min<uint64_t>(kChunk, total - o);
        uint32_t id;
        if (!free_chunks_.empty()) { id = free_chunks_.back(); free_chunks_.pop_back(); }
        else { id = (uint32_t) chunks_.size(); chunks_.push_back(Chunk{}); }
        chunks_[id] = Chunk{owner, at + o, len};
        if (!file_.submit(at + o, dst + o, len, (uint64_t) id, err)) return false;
        ++n_chunks;
    }
    stats_.bytes += total;
    return true;
}

bool TieredExpertSource::issue(int32_t s, int64_t layer, int64_t expert, std::string& err) {
    const strata::kernels::cpu::ExpertLayout& lay = strata::kernels::cpu::expert_layout();
    const uint64_t A = DirectFile::alignment();
    const uint64_t off = lay.blob_offset(layer, expert), bytes = lay.blob_bytes(layer);
    const uint64_t a0 = off / A * A, end = (off + bytes + A - 1) / A * A;
    delta_[(size_t) s] = (uint32_t) (off - a0);
    int32_t n = 0;
    state_[(size_t) s] = kLoading;
    ++in_flight_;
    if (!submit_range(s, host_ + (size_t) s * slot_bytes_, a0, end - a0, n, err)) {
        left_[(size_t) s] += n;   // the queued ones still complete
        return false;
    }
    left_[(size_t) s] += n;
    return true;
}

bool TieredExpertSource::reap(bool block, std::string& err) {
    Completion c[64];
    const int n = file_.wait(c, 64, block ? -1 : 0);
    bool ok = true;
    for (int i = 0; i < n; ++i) {
        if (c[i].tag == DirectFile::WAKE_TAG || c[i].tag >= chunks_.size()) continue;
        const Chunk ch = chunks_[(size_t) c[i].tag];
        free_chunks_.push_back((uint32_t) c[i].tag);
        // short only where the file ends (the last blob's page-rounded tail)
        if (!c[i].ok || (c[i].bytes != ch.len && ch.at + c[i].bytes < file_.size())) {
            err = "TieredExpertSource: a read of experts.bin failed or came back short";
            ok = false;
        }
        if (ch.owner == kBounce) {
            --bounce_left_;
        } else if (--left_[(size_t) ch.owner] == 0) {
            state_[(size_t) ch.owner] = kReady;
            --in_flight_;
        }
    }
    return ok;
}

void TieredExpertSource::begin_layer(int64_t layer, const int32_t* ids, int64_t k) {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_) return;
    ++serial_;
    // the resident ones first: touched, they are out of reach of this layer's own evictions
    for (int64_t i = 0; i < k; ++i) {
        const int32_t e = ids[i];
        if (e < 0 || e >= n_expert_) continue;
        const int64_t kk = key(layer, e);
        if (vram_res_ != nullptr && vram_res_[kk] >= 0) continue;
        const int32_t s = slot_of_[(size_t) kk];
        if (s < 0 || stamp_[(size_t) s] == serial_) continue;
        stamp_[(size_t) s] = serial_;
        unlink(s);
        push_front(s);
        ++stats_.lookups;
        ++stats_.hits;
        if (prefetched_[(size_t) s]) { prefetched_[(size_t) s] = 0; ++stats_.prefetch_used; }
        if (state_[(size_t) s] == kLoading) { need_.push_back(s); ++stats_.late; }
    }
    for (int64_t i = 0; i < k; ++i) {
        const int32_t e = ids[i];
        if (e < 0 || e >= n_expert_) continue;
        const int64_t kk = key(layer, e);
        if (vram_res_ != nullptr && vram_res_[kk] >= 0) continue;
        if (slot_of_[(size_t) kk] >= 0) continue;
        const int32_t s = victim();
        if (s < 0) { if (fail_.empty()) fail_ = "TieredExpertSource: no slot left to evict"; return; }
        if (key_of_[(size_t) s] >= 0) slot_of_[(size_t) key_of_[(size_t) s]] = -1;
        if (prefetched_[(size_t) s]) { prefetched_[(size_t) s] = 0; ++stats_.prefetch_evicted; }
        key_of_[(size_t) s] = (int32_t) kk;
        slot_of_[(size_t) kk] = s;
        stamp_[(size_t) s] = serial_;
        unlink(s);
        push_front(s);
        ++stats_.lookups;
        ++stats_.loads;
        need_.push_back(s);
        std::string err;
        if (!issue(s, layer, e, err) && fail_.empty()) fail_ = err;
    }
}

void TieredExpertSource::prefetch(int64_t layer, const int32_t* ids, int64_t n) {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_) return;
    // the current layer's slots carry this serial and are skipped by victim(); so do the ones admitted here
    for (int64_t i = 0; i < n; ++i) {
        const int32_t e = ids[i];
        if (e < 0 || e >= n_expert_) continue;
        const int64_t kk = key(layer, e);
        if (vram_res_ != nullptr && vram_res_[kk] >= 0) continue;
        if (slot_of_[(size_t) kk] >= 0) continue;
        const int32_t s = victim();
        if (s < 0) return;
        if (key_of_[(size_t) s] >= 0) slot_of_[(size_t) key_of_[(size_t) s]] = -1;
        if (prefetched_[(size_t) s]) ++stats_.prefetch_evicted;
        key_of_[(size_t) s] = (int32_t) kk;
        slot_of_[(size_t) kk] = s;
        stamp_[(size_t) s] = serial_;
        prefetched_[(size_t) s] = 1;
        unlink(s);
        push_front(s);
        ++stats_.prefetched;
        std::string err;
        if (!issue(s, layer, e, err) && fail_.empty()) fail_ = err;
    }
}

bool TieredExpertSource::wait_loads(std::string& err) {
    // only this layer's slots: a prefetch for the next layer keeps loading in the background
    if (!fail_.empty()) { err = fail_; need_.clear(); return false; }
    std::string rerr;
    if (!reap(false, rerr) && fail_.empty()) fail_ = rerr;   // collect whatever already landed
    auto pending = [&] {
        for (int32_t s : need_) if (state_[(size_t) s] == kLoading) return true;
        return false;
    };
    if (!pending()) { need_.clear(); return fail_.empty() ? true : (err = fail_, false); }
    const auto t0 = std::chrono::steady_clock::now();
    ++stats_.waited_layers;
    while (pending())
        if (!reap(true, err)) { fail_ = err; need_.clear(); return false; }
    stats_.wait_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    need_.clear();
    return true;
}

bool TieredExpertSource::pinned(int64_t layer, int64_t expert) const {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_ || expert < 0 || expert >= n_expert_) return false;
    const int32_t s = slot_of_[(size_t) key(layer, expert)];
    return s >= 0 && state_[(size_t) s] == kReady;
}

bool TieredExpertSource::loading(int64_t layer, int64_t expert) const {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_ || expert < 0 || expert >= n_expert_) return false;
    const int32_t s = slot_of_[(size_t) key(layer, expert)];
    return s >= 0 && state_[(size_t) s] == kLoading;
}

const uint8_t* TieredExpertSource::device_alias(int64_t layer, int64_t expert) const {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_ || expert < 0 || expert >= n_expert_) return nullptr;
    const int32_t s = slot_of_[(size_t) key(layer, expert)];
    if (s < 0) return nullptr;
    return dev_ + (size_t) s * slot_bytes_ + delta_[(size_t) s];
}

const uint8_t* TieredExpertSource::blob(int64_t layer, int64_t expert) {
    if (host_ == nullptr || layer < 0 || layer >= n_layers_ || expert < 0 || expert >= n_expert_) return nullptr;
    std::string err;
    const int32_t s = slot_of_[(size_t) key(layer, expert)];
    if (s >= 0) {
        while (state_[(size_t) s] == kLoading)
            if (!reap(true, err)) { if (fail_.empty()) fail_ = err; return nullptr; }
        return host_ + (size_t) s * slot_bytes_ + delta_[(size_t) s];
    }
    // not resident: the bounce buffer, not admitted
    const strata::kernels::cpu::ExpertLayout& lay = strata::kernels::cpu::expert_layout();
    const uint64_t A = DirectFile::alignment();
    const uint64_t off = lay.blob_offset(layer, expert), bytes = lay.blob_bytes(layer);
    const uint64_t a0 = off / A * A, end = (off + bytes + A - 1) / A * A;
    int32_t n = 0;
    const bool queued = submit_range(kBounce, bounce_, a0, end - a0, n, err);
    bounce_left_ += n;
    while (bounce_left_ > 0)
        if (!reap(true, err)) { if (fail_.empty()) fail_ = err; return nullptr; }
    if (!queued) { if (fail_.empty()) fail_ = err; return nullptr; }
    ++stats_.bounce;
    return bounce_ + (off - a0);
}

bool TieredExpertSource::warm_fill(const std::vector<std::pair<int32_t, int32_t>>& order, std::string& err) {
    if (host_ == nullptr) { err = "TieredExpertSource: not open"; return false; }
    // the free slots, hottest pair last so it ends up most recently used
    std::vector<std::pair<int32_t, int32_t>> take;
    int64_t room = 0;
    for (int64_t s = 0; s < n_slots_; ++s) room += state_[(size_t) s] == kFree && key_of_[(size_t) s] < 0;
    for (const auto& pr : order) {
        if ((int64_t) take.size() >= room) break;
        if (pr.first < 0 || pr.first >= n_layers_ || pr.second < 0 || pr.second >= n_expert_) continue;
        const int64_t kk = key(pr.first, pr.second);
        if (vram_res_ != nullptr && vram_res_[kk] >= 0) continue;
        if (slot_of_[(size_t) kk] >= 0) continue;
        take.push_back(pr);
    }
    ++serial_;
    for (auto it = take.rbegin(); it != take.rend(); ++it) {
        int32_t s = tail_;
        while (s >= 0 && !(state_[(size_t) s] == kFree && key_of_[(size_t) s] < 0)) s = prev_[(size_t) s];
        if (s < 0) break;
        const int64_t kk = key(it->first, it->second);
        key_of_[(size_t) s] = (int32_t) kk;
        slot_of_[(size_t) kk] = s;
        unlink(s);
        push_front(s);
        if (!issue(s, it->first, it->second, err)) return false;
        while (in_flight_ >= 32)
            if (!reap(true, err)) return false;
    }
    while (in_flight_ > 0)
        if (!reap(true, err)) return false;
    return true;
}

bool TieredExpertSource::read_blob_sync(int64_t layer, int64_t expert, uint8_t* dst, uint32_t& delta,
                                        std::string& err) const {
    if (sync_fd_ < 0 || layer < 0 || layer >= n_layers_ || expert < 0 || expert >= n_expert_) {
        err = "TieredExpertSource: read_blob_sync out of range";
        return false;
    }
    const strata::kernels::cpu::ExpertLayout& lay = strata::kernels::cpu::expert_layout();
    const uint64_t A = DirectFile::alignment();
    const uint64_t off = lay.blob_offset(layer, expert), bytes = lay.blob_bytes(layer);
    const uint64_t a0 = off / A * A, end = (off + bytes + A - 1) / A * A;
    uint64_t done = 0;
    while (a0 + done < end) {
        const ssize_t got = ::pread(sync_fd_, dst + done, (size_t) (end - a0 - done), (off_t) (a0 + done));
        if (got <= 0) {
            if (got == 0 && a0 + done >= off + bytes) break;   // the file ends inside the last page
            err = "TieredExpertSource: a synchronous read of experts.bin failed";
            return false;
        }
        done += (uint64_t) got;
    }
    delta = (uint32_t) (off - a0);
    return true;
}

int64_t TieredExpertSource::resident() const {
    int64_t n = 0;
    for (int32_t k : key_of_) n += k >= 0;
    return n;
}

}  // namespace strata::core
