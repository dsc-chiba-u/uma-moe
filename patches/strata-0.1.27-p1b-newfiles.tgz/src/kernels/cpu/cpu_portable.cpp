// src/kernels/cpu/cpu_portable.cpp - the CPU expert kernels on a CPU that is not x86 (aarch64: DGX Spark / GB10).
//
// Replaces expert.cpp, q2_avx2.cpp, iq_avx2.cpp and iq_avx512.cpp, which are x86 intrinsics throughout.  What a
// native (GGUF-form) pack needs on the CPU is implemented here:
//   - act_quant_q8_1: the scalar loop of expert.cpp, unchanged (so bitwise what the AVX-512 one produces);
//   - q2_0_gguf_rows_multi: the GGUF Q2_0 row dot, with NEON sdot where the CPU has it, the scalar formula of
//     s2_expert_scalar otherwise;
//   - the i-quant multi-token kernels report themselves unsupported, so native_expert.cpp takes ggml-cpu's vec_dot
//     (which has NEON code for every i-quant).
// The canonical Q2_0 pack (s2_expert_*) is AVX-512 only by design and is refused here as on any CPU without it.
#include "strata/kernels/cpu/expert.hpp"
#include "strata/kernels/cpu/iq_avx2.hpp"
#include "strata/kernels/cpu/iq_avx512.hpp"

#if defined(__ARM_FEATURE_DOTPROD)
#include <arm_neon.h>
#endif

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace strata::kernels::cpu {
namespace {

std::atomic<bool> oracle_q8_0{false};

[[noreturn]] void unsupported(const char* what) {
    std::fprintf(stderr, "strata: %s needs an x86 CPU with AVX-512 (the canonical Q2_0 pack); use a native pack on "
                         "this CPU\n", what);
    std::abort();
}

inline float h2f(const uint8_t* p) {
    uint16_t h;
    std::memcpy(&h, p, 2);
    const uint32_t sign = (uint32_t) (h >> 15) & 1u;
    uint32_t exp = (h >> 10) & 0x1Fu, man = h & 0x3FFu, f;
    if (exp == 0) {
        if (man == 0) {
            f = sign << 31;
        } else {
            exp = 127 - 15 + 1;
            while (!(man & 0x400u)) { man <<= 1; --exp; }
            man &= 0x3FFu;
            f = (sign << 31) | (exp << 23) | (man << 13);
        }
    } else if (exp == 31) {
        f = (sign << 31) | 0x7F800000u | (man << 13);
    } else {
        f = (sign << 31) | ((exp - 15 + 127) << 23) | (man << 13);
    }
    float out;
    std::memcpy(&out, &f, 4);
    return out;
}

// One GGUF Q2_0 row (blocks of 18 bytes: fp16 d, then 64 2-bit codes, value j at byte j/4, bits 2*(j%4); the weight
// is d * (code - 1)) against NT quantized activations.  As in the x86 kernels the -1 is folded into hx = scale * sum.
template <int NT>
inline void q2g_row_multi(const uint8_t* row, const ActQ* const* a, int nblocks, float* res) {
    float acc[NT];
    for (int t = 0; t < NT; ++t) acc[t] = 0.f;
    for (int b = 0; b < nblocks; ++b) {
        const uint8_t* blk = row + (size_t) b * 18;
        const float d = h2f(blk);
#if defined(__ARM_FEATURE_DOTPROD)
        const uint8x16_t raw = vld1q_u8(blk + 2), m3 = vdupq_n_u8(3);
        uint8x16x4_t c;
        c.val[0] = vandq_u8(raw, m3);
        c.val[1] = vandq_u8(vshrq_n_u8(raw, 2), m3);
        c.val[2] = vandq_u8(vshrq_n_u8(raw, 4), m3);
        c.val[3] = vshrq_n_u8(raw, 6);
        alignas(16) int8_t w[64];
        vst4q_u8((uint8_t*) w, c);       // w[4i+k] = c[k][i]: the codes in value order
        const int8x16_t w0 = vld1q_s8(w), w1 = vld1q_s8(w + 16), w2 = vld1q_s8(w + 32), w3 = vld1q_s8(w + 48);
        for (int t = 0; t < NT; ++t) {
            const int8_t* q = a[t]->q + b * 64;
            const int32x4_t lo = vdotq_s32(vdotq_s32(vdupq_n_s32(0), w0, vld1q_s8(q)), w1, vld1q_s8(q + 16));
            const int32x4_t hi = vdotq_s32(vdotq_s32(vdupq_n_s32(0), w2, vld1q_s8(q + 32)), w3, vld1q_s8(q + 48));
            acc[t] += d * (a[t]->scale[2 * b] * (float) vaddvq_s32(lo) + a[t]->scale[2 * b + 1] * (float) vaddvq_s32(hi) -
                           a[t]->hx[2 * b] - a[t]->hx[2 * b + 1]);
        }
#else
        int8_t w[64];
        for (int j = 0; j < 64; ++j) w[j] = (int8_t) ((blk[2 + (j >> 2)] >> (2 * (j & 3))) & 3);
        for (int t = 0; t < NT; ++t) {
            const int8_t* q = a[t]->q + b * 64;
            int32_t s0 = 0, s1 = 0;
            for (int j = 0; j < 32; ++j) s0 += w[j] * q[j];
            for (int j = 32; j < 64; ++j) s1 += w[j] * q[j];
            acc[t] += d * (a[t]->scale[2 * b] * (float) s0 + a[t]->scale[2 * b + 1] * (float) s1 -
                           a[t]->hx[2 * b] - a[t]->hx[2 * b + 1]);
        }
#endif
    }
    for (int t = 0; t < NT; ++t) res[t] = acc[t];
}

template <int NT>
void q2g_rows(const uint8_t* w, size_t row_bytes, int nblocks, const ActQ* const* a, float* const* out, int r0, int r1) {
    float res[NT];
    for (int r = r0; r < r1; ++r) {
        q2g_row_multi<NT>(w + (size_t) r * row_bytes, a, nblocks, res);
        for (int t = 0; t < NT; ++t) out[t][r] = res[t];
    }
}

}  // namespace

const char* CpuFeatures::reason() const { return usable() ? "ok" : "not an x86 CPU (no AVX-512)"; }

CpuFeatures cpu_features() { return CpuFeatures{}; }

void cpu_require_expert_support() {
    std::fprintf(stderr, "strata: this CPU cannot run the canonical Q2_0 expert kernel (it needs x86 AVX-512).\n"
                         "        Use a native pack (the GGUF experts) on this CPU.\n");
    std::exit(1);
}

void expert_set_oracle_q8_0(bool enabled) { oracle_q8_0.store(enabled, std::memory_order_relaxed); }
bool expert_oracle_q8_0_enabled() { return oracle_q8_0.load(std::memory_order_relaxed); }

void act_quant_q8_1(const float* x, int n, ActQ& a) {
    if (oracle_q8_0.load(std::memory_order_relaxed)) unsupported("the q8_0 oracle");
    a.nchunks = n / QKA;
    for (int k = 0; k < a.nchunks; ++k) {
        const float* xb = x + k * QKA;
        float amax = 0.f;
        for (int j = 0; j < QKA; ++j) amax = std::fmax(amax, std::fabs(xb[j]));
        const float s = amax > 0.f ? amax / 127.f : 0.f;
        const float inv = s > 0.f ? 1.f / s : 0.f;
        int32_t sum = 0;
        int8_t* q = a.q + k * QKA;
        for (int j = 0; j < QKA; ++j) {
            const float t = xb[j] * inv;
            const float r = t + (t >= 0.f ? 0.5f : -0.5f);   // lround's rule, see expert.cpp
            int v = (int) r;
            v = v < -127 ? -127 : (v > 127 ? 127 : v);
            q[j] = (int8_t) v;
            sum += v;
        }
        a.scale[k] = s;
        a.sum[k] = sum;
        a.hx[k] = s * (float) sum;
    }
}

void act_quant_q8_1_avx2(const float* x, int n, ActQ& a) { act_quant_q8_1(x, n, a); }

void q2_0_gguf_rows_multi(const uint8_t* w, size_t row_bytes, int nblocks, const ActQ* const* a, int nt,
                          float* const* out, int r0, int r1) {
    for (int t0 = 0; t0 < nt; t0 += 4) {
        const int k = nt - t0 < 4 ? nt - t0 : 4;
        switch (k) {
            case 1: q2g_rows<1>(w, row_bytes, nblocks, a + t0, out + t0, r0, r1); break;
            case 2: q2g_rows<2>(w, row_bytes, nblocks, a + t0, out + t0, r0, r1); break;
            case 3: q2g_rows<3>(w, row_bytes, nblocks, a + t0, out + t0, r0, r1); break;
            default: q2g_rows<4>(w, row_bytes, nblocks, a + t0, out + t0, r0, r1); break;
        }
    }
}

void q2_0_gguf_rows_multi_avx2(const uint8_t* w, size_t row_bytes, int nblocks, const ActQ* const* a, int nt,
                               float* const* out, int r0, int r1) {
    q2_0_gguf_rows_multi(w, row_bytes, nblocks, a, nt, out, r0, r1);
}

// ---- the canonical pack: x86 AVX-512 only ----
void s2_expert_vnni(const uint8_t*, const float*, float*, ExpertScratch&) { unsupported("s2_expert_vnni"); }
void s2_expert_vnni_q(const uint8_t*, const ActQ&, float*, ExpertScratch&) { unsupported("s2_expert_vnni_q"); }
void s2_expert_gu_rows(const uint8_t*, const ActQ&, float*, int, int) { unsupported("s2_expert_gu_rows"); }
void s2_expert_down_rows(const uint8_t*, const ActQ&, float*, int, int) { unsupported("s2_expert_down_rows"); }
void s2_expert_gu_rows_multi(const uint8_t*, const ActQ* const*, int, float* const*, int, int) {
    unsupported("s2_expert_gu_rows_multi");
}
void s2_expert_down_rows_multi(const uint8_t*, const ActQ* const*, int, float* const*, int, int) {
    unsupported("s2_expert_down_rows_multi");
}
void s2_expert_vnni_multi(const uint8_t*, const ActQ* const*, int, float* const*, ExpertScratchMulti&) {
    unsupported("s2_expert_vnni_multi");
}
void s2_expert_scalar(const uint8_t*, const float*, float*, bool) { unsupported("s2_expert_scalar"); }

// ---- the x86 i-quant multi-token kernels: never supported here, so native_expert.cpp uses ggml-cpu ----
bool iq256_supported(int) noexcept { return false; }
bool iq512_supported(int) noexcept { return false; }
void iq256_gu_rows(int, const uint8_t*, size_t, size_t, int, const void* const*, int, float* const*, int, int) {
    unsupported("iq256_gu_rows");
}
void iq256_rows(int, const uint8_t*, size_t, int, const void* const*, int, float* const*, int, int) {
    unsupported("iq256_rows");
}
void iq4nl256_down_rows(const uint8_t*, size_t, int, const void* const*, int, float* const*, int, int) {
    unsupported("iq4nl256_down_rows");
}
void iq512_gu_rows(int, const uint8_t*, size_t, size_t, int, const void* const*, int, float* const*, int, int) {
    unsupported("iq512_gu_rows");
}
void iq512_rows(int, const uint8_t*, size_t, int, const void* const*, int, float* const*, int, int) {
    unsupported("iq512_rows");
}

}  // namespace strata::kernels::cpu
